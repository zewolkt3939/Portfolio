(() => {
  document.documentElement.classList.add('js');
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('#primary-nav');
  if (toggle && nav) {
    toggle.hidden = false;
    const close = () => {
      toggle.setAttribute('aria-expanded', 'false');
      nav.classList.remove('is-open');
      toggle.querySelector('span').textContent = '+';
    };
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') !== 'true';
      toggle.setAttribute('aria-expanded', String(open));
      nav.classList.toggle('is-open', open);
      toggle.querySelector('span').textContent = open ? '−' : '+';
    });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
        close(); toggle.focus();
      }
    });
    matchMedia('(min-width: 761px)').addEventListener('change', close);
  }
  const filters = document.querySelector('.filter-bar');
  if (filters) {
    filters.hidden = false;
    filters.querySelectorAll('button').forEach(button => button.addEventListener('click', () => {
      filters.querySelectorAll('button').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
      let count = 0;
      document.querySelectorAll('.research-card').forEach(card => {
        card.hidden = button.dataset.filter !== 'all' && card.dataset.topic !== button.dataset.filter;
        if (!card.hidden) count++;
      });
      document.querySelector('#result-count').textContent = document.documentElement.lang === 'vi'
        ? `${count} bài viết`
        : `${count} ${count === 1 ? 'article' : 'articles'}`;
    }));
  }
  document.querySelectorAll('[data-copy-email]').forEach(button => button.addEventListener('click', async () => {
    const status = document.querySelector('.toast');
    const vietnamese = document.documentElement.lang === 'vi';
    try {
      await navigator.clipboard.writeText(button.dataset.copyEmail);
      status.textContent = vietnamese ? 'Đã sao chép email' : 'Email copied';
    }
    catch {
      status.textContent = (vietnamese ? 'Sao chép địa chỉ này: ' : 'Copy this address: ') + button.dataset.copyEmail;
    }
    window.setTimeout(() => { status.textContent = ''; }, 5000);
  }));
  document.querySelectorAll('pre').forEach(block => {
    if (block.querySelector('.copy-code')) return;
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'copy-code';
    button.textContent = document.documentElement.lang === 'vi' ? 'Sao chép' : 'Copy';
    button.addEventListener('click', async () => {
      await navigator.clipboard.writeText(block.innerText.replace(/^Copy|^Sao chép/, '').trim());
      button.textContent = document.documentElement.lang === 'vi' ? 'Đã chép' : 'Copied';
      setTimeout(() => { button.textContent = document.documentElement.lang === 'vi' ? 'Sao chép' : 'Copy'; }, 1800);
    });
    block.prepend(button);
  });
  const latest = document.querySelector('[data-latest-posts]');
  if (latest) {
    const vietnamese = document.documentElement.lang === 'vi';
    fetch('/api/v1/posts?page=1').then(response => {
      if (!response.ok) throw new Error('API unavailable');
      return response.json();
    }).then(data => {
      const list = latest.querySelector('[data-latest-list]');
      list.replaceChildren();
      data.items.slice(0, 3).forEach((post, index) => {
        const link = document.createElement('a'); link.className = 'work-row';
        link.href = `${vietnamese ? '/vi' : ''}/research/${post.slug}.html`;
        const number = document.createElement('span'); number.className = 'number'; number.textContent = String(index + 1).padStart(2, '0');
        const copy = document.createElement('div'); const title = document.createElement('h3'); title.textContent = vietnamese ? post.title_vi : (post.title_en || post.title_vi);
        const summary = document.createElement('p'); summary.textContent = vietnamese ? post.summary_vi : post.abstract_en;
        copy.append(title, summary);
        const meta = document.createElement('span'); meta.className = 'work-meta'; meta.textContent = `${post.kind.toUpperCase()} · ${post.reading_minutes} ${vietnamese ? 'phút' : 'min'}`;
        const arrow = document.createElement('span'); arrow.className = 'arrow'; arrow.setAttribute('aria-hidden', 'true'); arrow.textContent = '↗';
        link.append(number, copy, meta, arrow); list.append(link);
      });
    }).catch(() => latest.hidden = true);
  }
})();
