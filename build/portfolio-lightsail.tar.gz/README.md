# Nguyen Truong Bao — Cybersecurity Portfolio + CMS

A light, editorial portfolio inspired by a research notebook. Static profile,
project and certificate pages are paired with a FastAPI/PostgreSQL CMS for the
Research and Write-up section.

The site is bilingual. English routes remain at the repository root and the
Vietnamese counterparts live under `vi/`. The EN/VI control keeps visitors on
the equivalent page, including project and research detail pages. Research
articles retain their Vietnamese body and English abstract in both interface
languages because that bilingual editorial format is part of the article.

## Preview

```powershell
python -m pip install -e ".[dev]"
python -m portfolio_cms.cli init-db
python -m portfolio_cms.cli seed-legacy
uvicorn portfolio_cms.main:app --reload
```

Open `http://127.0.0.1:8000/`. The generated HTML files also work when opened directly.

## Pages

- `index.html` — concise introduction and selected work
- `about.html`, `experience.html`, `skills.html` — background and practical learning
- `projects.html` — project directory; `projects/` contains three case studies
- `certifications.html` — certificate, education and training records
- `research.html` — topic-filtered notebook with three experiments and three HTB reference write-ups
- `contact.html` — contact links, résumé and copy-email action
- `vi/` — Vietnamese counterparts for every route above

Primary navigation always opens a separate page. Only document contents and skip
links use in-page anchors. The active section remains indicated on detail pages.
Core content, language switching and navigation remain available without JavaScript.

## Edit and build

Edit static page bodies in `content/*.html`; `content/pages.json` defines routes,
titles, descriptions and navigation state. Vietnamese interface and content
translations live in `content/vi.json`. `tools/build_site.py` supplies the
shared localized header/footer, rewrites route paths and emits both languages.
Do not edit generated HTML for permanent content changes.

```powershell
python tools/build_site.py
python tools/check_site.py
```

Research and Write-up content lives in PostgreSQL. Open `/admin`, create a draft,
review the Markdown preview and publish checklist, then publish. Six original
articles are imported by the idempotent `seed-legacy` command. The static builder
no longer emits Research pages. Their initial Markdown lives in `seeds/posts/`;
after seeding, PostgreSQL is the only live content source.

The visual rationale is documented in [DESIGN.md](DESIGN.md). Shared styles are
in `styles.css`; menu/filter/copy behavior is in `script.js`.

## Reproducible research labs

Articles are Vietnamese with English abstracts, prepared with AI assistance.
They are educational experimental notes, not peer-reviewed publications or claims
of client pentesting work. Python code was executed locally on synthetic fixtures.

```powershell
python research/labs/run_labs.py
python tools/render_lab_figures.py
python tools/check_site.py
```

Python 3.10+ and the standard library are sufficient. The runner makes no network
requests or LLM calls and changes no host security controls. Its intentionally
vulnerable SQL query runs only in an in-memory SQLite teaching fixture.

- **SQL:** six fixtures, comparing string concatenation with parameter binding.
- **SOC:** twelve deliveries from eight distinct synthetic events; compare keys.
- **AI:** eight handcrafted candidate responses; test a deterministic validator.
  Malicious prose can pass its schema. No model resistance is measured.

`research/labs/results.json` contains inputs, outcomes, runtime versions, run UTC
and the SHA-256 of the executed source. `transcript.txt` records readable output.
SVG result figures are generated from that JSON, not fabricated screenshots.
Rerunning replaces the result files; preserve a dated copy before future changes
if you need to retain the published baseline. Update article figures and reported
runtime details when changing the experiment.

## Public deployment bundle

```powershell
python tools/build_site.py
python tools/check_site.py
python tools/package_site.py
python -m http.server 8001 --bind 127.0.0.1 --directory dist
```

The packager includes only public static pages,
assets, the supplied public résumé and educational lab artifacts. The original
internship PDFs, intake form and authoring sources are excluded. It removes stale
files from its own `dist/` output before updating the bundle.

Deploy the complete stack with `compose.yaml`. See [DEPLOYMENT.md](DEPLOYMENT.md)
for secrets, initial admin creation, encrypted off-site backup, restore testing,
releases and rollback.

The concrete production target is Amazon Lightsail 4 GB in Singapore. Follow
[LIGHTSAIL_DEPLOYMENT.md](LIGHTSAIL_DEPLOYMENT.md) for instance creation, DNS,
firewall, Docker, S3/Restic backup and the first restore drill.

## Evidence conventions

- LG reports describe a six-member team; contributions remain labeled as team work.
- OSSVS is based on the individual report; triaged CVEs and validated backports
  are distinct quantities.
- AI-APW follows Flask in the public implementation, as recorded in the intake form.
- The Google Cybersecurity certificate is supported by the supplied Coursera PDF,
  issued 31 December 2024 to Nguyễn Bảo, credential `YZZXJ9446ZZN`. The preview is
  rendered from that PDF; the verification link is embedded in the original.
- The owner confirmed 171 completed PortSwigger labs. CWES, COAE and CPTS are
  certification goals, not earned credentials.
- Appointment, Fawn and Redeemer are Vietnamese reference write-ups with English
  abstracts. They contain cited sources, step-by-step attack paths and commands
  for an authorized lab. They do not claim a live HTB run or personal completion.
- New labs are independent from existing project implementations and production
  systems. Their limitations and primary references appear in each article.

## Verification

`tools/check_site.py` checks every generated route in both languages, local
link, fragment, asset, single H1, duplicate ID, image alternative text,
page-based primary navigation, language alternate metadata and the executed lab
source hash. Browser review additionally covers desktop and mobile rendering,
language switching, route changes, topic filtering and copy-email feedback.

## Vietnamese typography and editing

Noto Sans and Noto Serif are served from `assets/fonts/`, including Vietnamese
letters and combining marks. The two variable WOFF2 files total about 134 KB.
They include SIL Open Font License files. `sources.json` records their URLs and
hashes. `python tools/prepare_fonts.py` optionally refreshes these assets from
Google Fonts; normal builds need no network access. Generated HTML is UTF-8/NFC.

Project, product, course and certification names stay in English. Vietnamese
prose uses “mình”. Add translations to `content/vi.json` when changing shared copy.
Certificate assets are explicitly allowlisted in the public bundle; source PDFs
outside that list remain excluded.
