"""Render standalone SVG result tables from executed JSON; no invented values."""
from pathlib import Path
from html import escape
import json

ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / 'research/labs/results.json').read_text(encoding='utf-8'))
OUT = ROOT / 'assets/research'
OUT.mkdir(parents=True, exist_ok=True)

def figure(name, title, subtitle, headings, rows, footer):
    xs = [36, 485, 680]
    desc = subtitle + '; ' + '; '.join(' / '.join(map(str,r)) for r in rows)
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="900" height="460" viewBox="0 0 900 460" role="img" aria-labelledby="title desc"><title id="title">{escape(title)}</title><desc id="desc">{escape(desc)}</desc><rect width="900" height="460" fill="#f0f1ea"/>']
    def text(x, y, value, size=16, color='#222722', family='Arial, sans-serif'):
        parts.append(f'<text x="{x}" y="{y}" fill="{color}" font-size="{size}" font-family="{family}">{escape(str(value))}</text>')
    text(36, 44, 'LAB NOTE / EXECUTED RESULTS', 12, '#405d47', 'Consolas, monospace')
    text(36, 84, title, 30, family='Georgia, serif')
    text(36, 115, subtitle, 14, '#60665e')
    for x, heading in zip(xs, headings): text(x, 161, heading, 13, '#60665e')
    for i, row in enumerate(rows):
        y = 193 + i * 32
        parts.append(f'<path d="M36 {y-19} H864" stroke="#d0d5ca"/>')
        for x, value in zip(xs, row): text(x, y+3, value, 15)
    text(36, 422, footer, 13, '#405d47', 'Consolas, monospace')
    parts.append('</svg>')
    (OUT / name).write_text(''.join(parts), encoding='utf-8')

def outcome(value): return 'SQL error' if value == 'SQL error' else ('Allow' if value else 'Deny')
figure('sql-results.svg', 'Data stays data.', 'SQLite in-memory fixture / six test cases / no network target',
       ['Test case', 'Concatenation', 'Parameters'],
       [(r['case'], outcome(r['concatenation']), outcome(r['parameterized'])) for r in DATA['sql']['cases']],
       f"Correct outcomes: {DATA['sql']['unsafe_correct']}/6 vs {DATA['sql']['safe_correct']}/6 | See raw JSON for inputs")
d=DATA['dedup']
figure('dedup-results.svg', 'Similar text. Distinct events.', 'Synthetic event replay / one manager / two agents',
       ['Observation', 'Count', 'Meaning'],
       [('Incoming deliveries', d['raw_deliveries'], '8 events + 4 retries'), ('Ground truth', d['ground_truth'], 'Distinct source IDs'), ('Content-key retention', d['naive_retained'], '7 events lost'), ('Identity-key retention', d['identity_retained'], 'No fixture event lost'), ('Duplicate deliveries removed',d['raw_deliveries']-d['identity_retained'],'Source identity key')],
       'Ground truth is constructed, not a production measurement.')
a=DATA['ai']
figure('ai-results.svg', 'A schema is only one boundary.', 'Handcrafted responses / no LLM calls / no action executor',
       ['Observation', 'Count', 'Interpretation'],
       [('Candidate responses',len(a['cases']),'Hand-authored'), ('Rejected by policy',a['rejected'],'Schema / ID / priority'), ('Accepted as text',a['accepted'],'Analyst review only'), ('Malicious prose accepted',1,'Known limitation'), ('Actions executed',a['executed_actions'],'No executor present')],
       'This test does not measure model resistance to prompt injection.')
print('Rendered 3 SVG result figures from results.json.')
